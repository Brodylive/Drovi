-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 11 Juin 2014 à 20:53
-- Version du serveur: 5.1.73
-- Version de PHP: 5.3.3-7+squeeze19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `jenniferdenis`
--

-- --------------------------------------------------------

--
-- Structure de la table `drovi_conges`
--

CREATE TABLE IF NOT EXISTS `drovi_conges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_magasin` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `horaire` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Contenu de la table `drovi_conges`
--

INSERT INTO `drovi_conges` (`id`, `nom_magasin`, `date`, `horaire`) VALUES
(5, 'Lidl Jambes', '2015-01-01', 'fermÃ©'),
(19, 'Le Saint Loup Namur', '2015-01-01', 'fermÃ©'),
(6, 'Lidl Jambes', '2014-12-25', 'fermÃ©'),
(7, 'Louis Delhaize Parc d\\''AmÃ©e', '2015-01-01', 'fermÃ©'),
(8, 'Louis Delhaize Parc d\\''AmÃ©e', '2014-12-25', 'fermÃ©'),
(9, 'La Plage d\\''AmÃ©e', '2015-01-01', 'fermÃ©'),
(10, 'La Plage d\\''AmÃ©e', '2014-12-25', 'fermÃ©'),
(11, 'Les Caves Ã  BiÃ¨res', '2015-01-01', 'fermÃ©'),
(12, 'Les Caves Ã  BiÃ¨res', '2014-12-25', 'fermÃ©'),
(13, 'Shop Place des Cadets', '2015-01-01', 'fermÃ©'),
(14, 'Shop Place des Cadets', '2014-12-25', 'fermÃ©'),
(15, 'Sexy Dreams Namur', '2015-01-01', 'fermÃ©'),
(16, 'Sexy Dreams Namur', '2014-12-25', 'fermÃ©'),
(17, 'L\\''Entre Sambre et Mer', '2015-01-01', 'fermÃ©'),
(18, 'L\\''Entre Sambre et Mer', '2014-12-25', 'fermÃ©'),
(20, 'Le Saint Loup Namur', '2014-12-25', 'fermÃ©'),
(21, 'Top Dil Namur', '2015-01-01', 'fermÃ©'),
(22, 'Top Dil Namur', '2014-12-25', 'fermÃ©'),
(25, 'Le Bercha', '2014-07-27', 'fermÃ©'),
(24, 'Chi-Chi\\''s Namur', '2015-01-01', 'fermÃ©'),
(26, 'Le Bercha', '2014-08-10', 'fermÃ©'),
(27, 'ThaÃ¯ Store', '2015-01-01', '09:30:00 to 13:00:00'),
(28, 'ThaÃ¯ Store', '2014-12-25', '09:30:00 to 13:00:00'),
(29, 'ThaÃ¯ Store', '2014-08-15', '09:30:00 to 13:00:00'),
(30, 'Trafic Binche', '2015-01-01', 'fermÃ©'),
(31, 'Trafic Binche', '2014-12-25', 'fermÃ©'),
(32, 'Next Mons', '2015-01-01', 'fermÃ©'),
(33, 'Next Mons', '2014-12-25', 'fermÃ©');

-- --------------------------------------------------------

--
-- Structure de la table `drovi_favoris`
--

CREATE TABLE IF NOT EXISTS `drovi_favoris` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `magasin` varchar(50) NOT NULL,
  `id_magasin` int(11) NOT NULL,
  `utilisateur` varchar(50) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Contenu de la table `drovi_favoris`
--

INSERT INTO `drovi_favoris` (`id`, `magasin`, `id_magasin`, `utilisateur`, `id_user`) VALUES
(1, 'Le CollÃ¨ge', 12, 'Jenny', 2),
(40, 'Supershooting', 24, 'Jenny', 2),
(7, 'The Green Fairy', 6, 'Jenny', 2),
(10, 'Starbuck', 16, 'Jenny', 2),
(5, 'Chicken Spot', 4, 'Jenny', 2),
(12, 'Agora', 17, 'Jenny', 2),
(13, 'Spar Express', 3, 'Jenny', 2),
(14, 'Match', 2, 'Jenny', 2),
(25, 'Le Chaudron Magique', 37, 'Jenny', 2),
(26, 'Chicken Spot', 4, 'Super-Brego', 10),
(27, 'Spar', 1, 'Super-Brego', 10),
(28, 'The Green Fairy', 6, 'Super-Brego', 10),
(29, 'Le CollÃ¨ge', 12, 'Super-Brego', 10),
(30, 'Night and Day Presse', 11, 'Super-Brego', 10),
(37, 'Lovely Sins', 5, 'Jenny', 2),
(32, 'Cat''s Corner', 36, 'Super-Brego', 10),
(33, 'The Green Fairy', 6, 'Raku', 12),
(34, 'Celtica', 75, 'Raku', 12),
(35, 'Wash in town', 82, 'Jenny', 2),
(36, 'Pizza Hut Namur', 72, 'pixeline', 9),
(38, 'Friterie de l''Avenir', 94, 'Jenny', 2),
(41, 'Trafic Binche', 102, 'Jenny', 2),
(42, 'Trafic Binche', 102, 'heaj_test', 24),
(43, 'Le Chaudron Magique', 37, 'SuperGlue47', 8);

-- --------------------------------------------------------

--
-- Structure de la table `drovi_magasins`
--

CREATE TABLE IF NOT EXISTS `drovi_magasins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `adresse` varchar(50) DEFAULT NULL,
  `latLng` varchar(50) DEFAULT NULL,
  `cat` varchar(11) DEFAULT NULL,
  `1` varchar(50) DEFAULT NULL,
  `2` varchar(50) DEFAULT NULL,
  `3` varchar(50) DEFAULT NULL,
  `4` varchar(50) DEFAULT NULL,
  `5` varchar(50) DEFAULT NULL,
  `6` varchar(50) DEFAULT NULL,
  `0` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=107 ;

--
-- Contenu de la table `drovi_magasins`
--

INSERT INTO `drovi_magasins` (`id`, `nom`, `description`, `adresse`, `latLng`, `cat`, `1`, `2`, `3`, `4`, `5`, `6`, `0`) VALUES
(1, 'Spar Namur', NULL, 'Rue des Croisiers 8, 5000 Namur', '50.467345, 4.864583', 'alimentaire', '09:00:00 to 18:30:00', '09:00:00 to 18:30:00', '09:00:00 to 18:30:00', '09:00:00 to 18:30:00', '09:00:00 to 18:30:00', '09:00:00 to 18:30:00', NULL),
(2, 'Match Namur', NULL, 'Coin rue des Echasseurs et Bailly, 5000 Namur', '50.462592, 4.865971', 'alimentaire', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', NULL),
(3, 'Spar Express', NULL, 'Rue Saint-Nicolas 64, 5000 Namur', '50.464858, 4.873714', 'alimentaire', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', NULL),
(4, 'Chicken Spot', '', 'Rue Rogier 61, 5000 Namur', '50.4674509, 4.86825060000001', 'horeca', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(96, 'Le Saint Loup Namur', 'Restaurant - fondues, pierrades, ...', '25 - 27 Rue du CollÃ¨ge, 5000 Namur', '50.4636955, 4.86291140000003', 'horeca', '18:00:00 to 22:00:00', '18:00:00 to 22:00:00', '18:00:00 to 22:00:00', '18:00:00 to 22:00:00', '18:00:00 to 22:00:00', '18:00:00 to 22:00:00', '12:00:00 to 22:00:00'),
(5, 'Lovely Sins', 'Loveshop', 'Rue des Dames Blanches 40, 5000 Namur', '50.467188, 4.866177', 'boutique', '12:00:00 to 19:00:00', '12:00:00 to 19:00:00', '12:00:00 to 19:00:00', '12:00:00 to 19:00:00', '12:00:00 to 19:00:00', '12:00:00 to 19:00:00', NULL),
(6, 'The Green Fairy', NULL, 'Rue Godefroid 64, 5000 Namur', '50.467942, 4.862606', 'horeca', '00:00:00 to 01:00:00 and 07:30:00 to 24:00:00', '00:00:00 to 01:00:00 and 07:30:00 to 24:00:00', '00:00:00 to 01:00:00 and 07:30:00 to 24:00:00', '00:00:00 to 01:00:00 and 07:30:00 to 24:00:00', '00:00:00 to 01:00:00 and 07:30:00 to 24:00:00', '00:00:00 to 02:00:00 and 07:30:00 to 24:00:00', '00:00:00 to 02:00:00 and 07:30:00 to 24:00:00'),
(7, 'Pharmacie Servais', NULL, 'Place de la Station 17, 5000 Namur', '50.468135, 4.862315', 'pharmacie', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Superphar', NULL, 'Rue des Echasseurs 2, 5000 Namur', '50.462681, 4.865955', 'pharmacie', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 19:00:00', '09:00:00 to 13:00:00', NULL),
(73, 'Mediamarkt', 'Electronique et electro-mÃ©nager', 'Rue Neuve 111, 1000 Bruxelles', '50.8529782, 4.356334800000013', 'boutique', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 20:00:00', '10:00:00 to 19:00:00', NULL),
(10, 'Night and Day Presse Salzinnes', NULL, 'Square LÃ©opold 20, 5000 Namur', '50.468872, 4.867106', 'nightshop', '10:00:00 to 22:00:00', '10:00:00 to 22:00:00', '10:00:00 to 22:00:00', '10:00:00 to 22:00:00', '10:00:00 to 22:00:00', '10:00:00 to 22:00:00', '10:00:00 to 22:00:00'),
(11, 'Night and Day Presse', '', 'Place Wiertz 18, 5000 Namur', '50.4644314, 4.848537899999997', 'nightshop', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 01:00:00 and 10:00:00 to 24:00:00'),
(12, 'Le CollÃ¨ge', NULL, 'Rue du CollÃ¨ge 15, 5000 Namur', '50.463698, 4.863364', 'horeca', NULL, '10:00:00 to 20:00:00', '10:00:00 to 20:00:00', '10:00:00 to 20:00:00', '10:00:00 to 20:00:00', NULL, NULL),
(13, 'AdrÃ¨naline', 'Tatoueur', 'Rue Pepin 41 5000 Namur', '50.466310, 4.869731', 'autre', NULL, NULL, '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '13:00:00 to 18:00:00', NULL),
(14, 'Sushi Garden', NULL, '48 Rue Emile Cuvelier 5000 Namur', '50.464872, 4.865603', 'horeca', '11:00:00 to 19:00:00', '11:00:00 to 19:00:00', '11:00:00 to 19:00:00', '11:00:00 to 19:00:00', '11:00:00 to 19:00:00', '11:00:00 to 19:00:00', NULL),
(15, 'Psychodermo', 'Tatoueur', 'rue des Carmes,9 5000 Namur', '50.465298, 4.863654', 'autre', '10:30:00 to 18:00:00', '10:30:00 to 18:00:00', '10:30:00 to 18:00:00', NULL, '10:30:00 to 18:00:00', '10:30:00 to 18:00:00', NULL),
(16, 'Starbuck Namur', NULL, 'Place de la station, 5000 namur', '50.468655, 4.862798', 'horeca', '06:00:00 to 20:00:00', '06:00:00 to 20:00:00', '06:00:00 to 20:00:00', '06:00:00 to 20:00:00', '06:00:00 to 20:00:00', '07:30:00 to 19:30:00', '07:30:00 to 19:30:00'),
(37, 'Le Chaudron Magique', NULL, 'Rue de Mons 11, Estinnes-au-val', '50.4226789, 4.121765399999958', 'horeca', NULL, NULL, NULL, '18:00:00 to 24:00:00', '18:00:00 to 24:00:00', '18:00:00 to 24:00:00', '12:00:00 to 16:00:00'),
(17, 'Agora', 'Librairie', '53-55 rue Emile Cuvelier 5000 Namur ', '50.4648374, 4.865638799999942', 'boutique', '09:30:00 to 18:00:00', '09:30:00 to 18:00:00', '09:30:00 to 18:00:00', '09:30:00 to 18:00:00', '09:30:00 to 18:00:00', '10:00:00 to 18:00:00', 'NULL to NULL'),
(20, 'Cordonnier des Carmes', NULL, 'Rue des Carmes, 79 5000 Namur', '50.4675647, 4.863438599999995', 'autre', NULL, '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', '09:00:00 to 18:00:00', NULL),
(24, 'Supershooting', 'Centre de tir sportif et armurerie', 'avenue LÃ©opold 3, 40 7134 PÃ©ronnes', '50.42807029999999, 4.133688500000062', 'autre', NULL, NULL, '17:00:00 to 22:00:00', '17:00:00 to 22:00:00', '14:30:00 to 22:00:00', '10:00:00 to 20:00:00', '09:30:00 to 13:00:00'),
(36, 'Cat\\''s Corner', '', 'Place Chanoine Descamps 10 namur', '50.46265349999999, 4.864394100000027', 'horeca', '11:00:00 to 24:00:00', '11:30:00 to 24:00:00', '11:30:00 to 24:00:00', '11:30:00 to 24:00:00', '11:30:00 to 24:00:00', '11:30:00 to 24:00:00', '18:00:00 to 24:00:00'),
(38, 'La Boiserie Habitat', 'Magasin de menuiserie', 'Route de Mons 503, 7131 Waudrez', '50.421657, 4.127008', 'autre', '07:30:00 to 12:30:00 and 13:30:00 to 17:30:00', '07:30:00 to 12:30:00 and 13:30:00 to 17:30:00', '07:30:00 to 12:30:00 and 13:30:00 to 17:30:00', '07:30:00 to 12:30:00 and 13:30:00 to 17:30:00', '07:30:00 to 12:30:00 and 13:30:00 to 17:30:00', '08:30:00 to 16:00:00', NULL),
(39, 'Quick Namur', NULL, ' 7 Avenue de la Gare, 5000', '50.4682227, 4.86323189999996', 'horeca', '10:00:00 to 23:00:00', '10:00:00 to 23:00:00', '10:00:00 to 23:00:00', '10:00:00 to 23:00:00', '10:00:00 to 23:00:00', '10:00:00 to 23:00:00', '10:00:00 to 23:00:00'),
(72, 'Pizza Hut Namur', NULL, 'Rue Jean-Baptiste Brabant 17, Namur', '50.4654524, 4.872267500000021', 'horeca', '11:30:00 to 22:00:00', '11:30:00 to 22:00:00', '11:30:00 to 22:00:00', '11:30:00 to 22:00:00', '11:30:00 to 22:00:00', '11:30:00 to 22:00:00', '11:30:00 to 22:00:00'),
(71, 'McDo Namur', NULL, 'Avenue de la Gare 11, 5000 Namur', '50.4680865, 4.864539100000002', 'horeca', '09:00:00 to 22:00:00', '09:00:00 to 22:00:00', '09:00:00 to 22:00:00', '09:00:00 to 22:00:00', '09:00:00 to 22:00:00', '09:30:00 to 24:00:00', '11:00:00 to 22:00:00'),
(74, 'Proxy Delhaize Manhattan', 'Delhaize de proximitÃ©', 'Avenue du Boulevard 21/35,  1210 Saint-Josse-ten-N', '50.8560988, 4.356771500000036', 'alimentaire', '08:00:00 to 20:00:00', '08:00:00 to 20:00:00', '08:00:00 to 20:00:00', '08:00:00 to 20:00:00', '08:00:00 to 20:00:00', '08:00:00 to 20:00:00', NULL),
(75, 'Celtica', '', 'Rue du MarchÃ© aux Poulets 55, 1000 Brussels', '50.8484766, 4.351320499999929', 'horeca', '00:00:00 to 05:00:00 and 13:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 13:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 13:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 13:00:00 to 24:00:00', '00:00:00 to 06:00:00 and 13:00:00 to 24:00:00', '00:00:00 to 07:00:00 and 13:00:00 to 24:00:00', '00:00:00 to 07:00:00 and 13:00:00 to 24:00:00'),
(76, 'Colruyt Etterbeek', 'SupermarchÃ© Colruyt', 'RUE GRAY 102, 1040 ETTERBEEK', '50.8342713, 4.379253299999959', 'alimentaire', '08:00:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 21:00:00', '08:30:00 to 20:00:00', NULL),
(77, 'MMPharma', '', 'Rue du Marais, 7-9 1000 Bruxelles', '50.8505651, 4.357998899999984', 'pharmacie', '08:30:00 to 14:30:00 and 15:30:00 to 18:00:00', '08:30:00 to 14:30:00 and 15:30:00 to 18:00:00', '08:30:00 to 14:30:00 and 15:30:00 to 18:00:00', '08:30:00 to 14:30:00 and 15:30:00 to 18:00:00', '08:30:00 to 14:30:00 and 15:30:00 to 18:00:00', NULL, NULL),
(78, 'La maison du signe', 'Restaurant sur la Grand Place', ' Grand Place 9, 1000 Bruxelles', '50.8462815, 4.352378799999997', 'horeca', '12:00:00 to 14:30:00 and 19:00:00 to 22:30:00', '12:00:00 to 14:30:00 and 19:00:00 to 22:30:00', '12:00:00 to 14:30:00 and 19:00:00 to 22:30:00', '12:00:00 to 14:30:00 and 19:00:00 to 22:30:00', '12:00:00 to 14:30:00 and 19:00:00 to 22:30:00', '19:00:00 to 22:30:00', NULL),
(79, 'Le coq d\\''Or', 'Snack/restaurant', 'avenue du Bois de la Cambre 2, 1170 Watermael-Boit', '50.8098446, 4.396936099999948', 'horeca', '11:30:00 to 14:00:00 and 18:00:00 to 22:00:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:00:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:00:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:00:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:00:00', '18:00:00 to 22:00:00', '18:00:00 to 22:00:00'),
(80, 'Mc Donald', '', 'Rue Neuve 124, 1000 Ville de Bruxelles ', '50.8543813, 4.35740009999995', 'horeca', '09:00:00 to 23:00:00', '09:00:00 to 23:00:00', '09:00:00 to 23:00:00', '09:00:00 to 23:00:00', '09:00:00 to 23:00:00', '09:00:00 to 23:00:00', '09:00:00 to 23:00:00'),
(81, 'La godasse', 'Cordonnerie', 'ChaussÃ©e de Charleroi 16, 5000 Namur', '50.463009, 4.84362950000002', 'autre', NULL, '09:00:00 to 12:00:00 and 13:30:00 to 18:00:00', '09:00:00 to 12:00:00 and 13:30:00 to 18:00:00', '09:00:00 to 12:00:00 and 13:30:00 to 18:00:00', '09:00:00 to 12:00:00 and 13:30:00 to 18:00:00', '09:00:00 to 12:00:00 and 13:30:00 to 16:00:00', NULL),
(82, 'Wash in town', 'Laverie automatique', 'Rue de Bruxelles 26, 5000 Namur ', '50.4655351, 4.8625441000000365', 'autre', '08:00:00 to 18:00:00', '08:00:00 to 18:00:00', '08:00:00 to 18:00:00', '08:00:00 to 18:00:00', '08:00:00 to 18:00:00', '09:00:00 to 17:00:00', NULL),
(83, 'Palais d\\''Ã©tÃ©', 'restaurant asiatique', 'avenue Cardinal Mercier 1, 5000 Namur', '50.46498949999999, 4.850275600000032', 'horeca', '12:00:00 to 15:00:00 and 18:00:00 to 24:00:00', NULL, '12:00:00 to 15:00:00 and 18:00:00 to 24:00:00', '12:00:00 to 15:00:00 and 18:00:00 to 24:00:00', '12:00:00 to 15:00:00 and 18:00:00 to 24:00:00', '12:00:00 to 15:00:00 and 18:00:00 to 24:00:00', '12:00:00 to 15:00:00 and 18:00:00 to 24:00:00'),
(84, 'Lidl Jambes', '', 'Rue Major Mascaux 230, 5100 Jambes', '50.4441561, 4.868084299999964', 'alimentaire', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 19:00:00', NULL),
(85, 'Louis Delhaize Parc d\\''AmÃ©e', '', 'Avenue Parc d\\''AmÃ©e 1-3, 5100 Jambes', '50.44034569999999, 4.865695800000026', 'alimentaire', '07:00:00 to 18:00:00', '07:00:00 to 18:00:00', '07:00:00 to 18:00:00', '07:00:00 to 18:00:00', '07:00:00 to 18:00:00', '07:30:00 to 18:00:00', NULL),
(86, 'La Plage d\\''AmÃ©e', '', 'Rue des Peupliers 2, 5100 Jambes', '50.4376324, 4.864250299999981', 'horeca', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 24:00:00', NULL),
(87, 'Les Caves Ã  BiÃ¨res', 'Bar Ã©tudiant', 'Rue Godefroid 68, 5000 Namur', '50.46757729999999, 4.862537599999996', 'horeca', '07:00:00 to 24:00:00 and 00:00:00 to 01:00:00', '07:00:00 to 24:00:00 and 00:00:00 to 01:00:00', '07:00:00 to 24:00:00 and 00:00:00 to 01:00:00', '07:00:00 to 24:00:00 and 00:00:00 to 01:00:00', '07:00:00 to 24:00:00 and 00:00:00 to 01:00:00', '08:00:00 to 24:00:00 and 00:00:00 to 02:00:00', '08:00:00 to 24:00:00 and 00:00:00 to 02:00:00'),
(88, 'Shop Place des Cadets', '', 'Place des Cadets 33, 5000 Namur', '50.4661003, 4.877005700000041', 'nightshop', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 05:00:00 and 10:00:00 to 24:00:00'),
(89, 'Sexy Dreams Namur', 'Loveshop', 'Rue Godefroid 24, 5000 Namur', '50.4667001, 4.86251500000003', 'boutique', '10:00:00 to 19:00:00', '10:30:00 to 19:30:00', '10:30:00 to 19:30:00', '10:30:00 to 19:30:00', '10:30:00 to 19:30:00', '10:30:00 to 19:30:00', NULL),
(90, 'L\\''Entre Sambre et Mer', 'Restaurant, cuisine de la mer', 'Rue des Brasseurs 110, 5000 Namur', '50.4620131, 4.86436290000006', 'horeca', NULL, '12:00:00 to 14:00:00 and 18:30:00 to 21:00:00', '12:00:00 to 14:00:00 and 18:30:00 to 21:00:00', '12:00:00 to 14:00:00 and 18:30:00 to 21:00:00', '12:00:00 to 14:00:00 and 18:30:00 to 21:00:00', '12:00:00 to 14:00:00 and 18:30:00 to 21:00:00', NULL),
(91, 'Pizzaiolo & Mozzarella', 'Pizzeria', 'Route de Mons 28, 7120 Estinnes', '50.4194916, 4.133869699999991', 'horeca', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00', '11:30:00 to 14:00:00 and 18:00:00 to 22:30:00'),
(92, 'ExtrÃªme-Orient', 'Traiteur Asiatique', 'Rue de la clef 11, 7000 Mons', '50.453831, 3.9525610000000597', 'horeca', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(93, 'Friterie du parc', 'Friterie et spÃ©cialitÃ©s vietnamiennes', 'Rempart de la Vierge, 5000 Namur', '50.4664583, 4.857208799999967', 'horeca', '11:00:00 to 14:00:00 and 16:00:00 to 22:00:00', '11:00:00 to 14:00:00 and 16:00:00 to 22:00:00', '11:00:00 to 14:00:00 and 16:00:00 to 22:00:00', '11:00:00 to 14:00:00 and 16:00:00 to 22:00:00', '11:00:00 to 14:00:00 and 16:00:00 to 22:00:00', '11:30:00 to 15:00:00 and 17:00:00 to 20:30:00', NULL),
(94, 'Friterie de l\\''Avenir', 'Friterie', 'Boulevard Ernest Melot 23, Namur', '50.4682651, 4.860912900000017', 'horeca', '00:00:00 to 24:00:00', '00:00:00 to 24:00:00', '00:00:00 to 24:00:00', '00:00:00 to 24:00:00', '00:00:00 to 24:00:00', '00:00:00 to 24:00:00', '00:00:00 to 24:00:00'),
(97, 'Top Dil Namur', 'DÃ©coration, alimentaire, vÃªtements, ...', ' Rue des Echasseurs 5, 5000 Namur', '50.4626143, 4.866059599999971', 'boutique', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '14:00:00 to 18:00:00'),
(98, 'Australian Namur', 'Home Made Icecream', 'Rue de l\\''Ange 64, 5000 Namen', '50.4644229, 4.8651669999999285', 'horeca', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', '10:00:00 to 19:00:00', NULL),
(99, 'Chi-Chi\\''s Namur', 'Tex-Mex restaurant & bar', 'Rue du CollÃ¨ge 19, 5000 Namur', '50.4637057, 4.86312369999996', 'horeca', '12:00:00 to 22:00:00', '12:00:00 to 22:00:00', '12:00:00 to 22:00:00', '12:00:00 to 22:00:00', '11:30:00 to 23:00:00', '11:30:00 to 23:00:00', '11:30:00 to 22:00:00'),
(100, 'Le Bercha', '', '763 Route de Mons ,7130 Bray', '50.427013, 4.099702999999977', 'horeca', NULL, NULL, '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 23:00:00', '11:30:00 to 14:00:00 and 19:00:00 to 24:00:00', '11:30:00 to 14:00:00'),
(101, 'ThaÃ¯ Store', 'Magasin asiatique', 'Boulevard Cauchy 23, 5000 Namur', '50.4687071, 4.87077899999997', 'alimentaire', '09:00:00 to 17:00:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 13:00:00'),
(102, 'Trafic Binche', '', 'Route de Mons 401, 7131 Waudrez (Binche)', '50.4200382, 4.131781400000023', 'boutique', '13:00:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 18:30:00', '09:30:00 to 12:30:00'),
(103, 'Next Mons', 'Informatique', '16, rue de la Petite Guirlande, 7000 Mons', '50.4515529, 3.9452784000000065', 'boutique', NULL, '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', '10:00:00 to 18:00:00', NULL),
(104, 'Colruyt Salzinnes', 'SupermarchÃ© Colruyt', 'ChaussÃ©e de Charleroi 16 Namur', '50.463009, 4.84362950000002', 'alimentaire', '08:00:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 20:00:00', '08:30:00 to 21:00:00', '08:30:00 to 20:00:00', NULL),
(105, 'DÃ¶ner Hut', 'Kebab', 'Rue Emile Cuvelier,  5000 Namur', '50.46440579999999, 4.86674389999996', 'horeca', '10:00:00 to 24:00:00', '10:00:00 to 24:00:00', '10:00:00 to 24:00:00', '10:00:00 to 24:00:00', '10:00:00 to 24:00:00', '10:00:00 to 24:00:00', '10:00:00 to 24:00:00'),
(106, 'Dallas Salzinnes', '', ' Place Wiertz,  5000 Namur', '50.4642932, 4.849040599999967', 'nightshop', '00:00:00 to 02:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 02:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 02:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 02:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 02:00:00 and 10:00:00 to 24:00:00', '00:00:00 to 02:30:00 and 10:00:00 to 24:00:00', '00:00:00 to 02:00:00 and 10:00:00 to 24:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `drovi_report`
--

CREATE TABLE IF NOT EXISTS `drovi_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_magasin` int(11) DEFAULT NULL,
  `nom_magasin` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `drovi_report`
--


-- --------------------------------------------------------

--
-- Structure de la table `drovi_users`
--

CREATE TABLE IF NOT EXISTS `drovi_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(51) DEFAULT NULL,
  `email` varchar(51) DEFAULT NULL,
  `password` varchar(51) DEFAULT NULL,
  `niveau` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `drovi_users`
--

INSERT INTO `drovi_users` (`id`, `username`, `email`, `password`, `niveau`, `date`) VALUES
(2, 'Jenny', 'brodylive@gmail.com', '*2FB180ACBB7AB0C27D1793C619BA1B118DC77F4A', 1503, '2014-03-05'),
(8, 'SuperGlue47', 'brodypattyns@gmail.com', '*CF6E1674E36B571CA309370F6613C85CFD8ABE08', 33, '2014-04-25'),
(10, 'Super-Brego', 'link_0209@hotmail.com', '*8AAB8B152E494545A88F6086B80547632D878E28', 300, '2014-05-01'),
(9, 'pixeline', 'alexandre@pixeline.be', '*AA81EEF4C76961256005B412AA1D40FE9CCF0D7B', 8, '2014-05-17'),
(11, 'jeromerenders', 'jeromerenders@gmail.com', '*676243218923905CF94CB52A3C9D3EB30CE8E20D', 2, '2014-05-17'),
(12, 'Raku', 'oligiama@hotmail.fr', '*019A71A00B37D93412B65B1F305AC6DC63FD4EE3', 11, '2014-05-17'),
(13, 'kooka', 'lekooka@gmail.com', '*93BD0162BD1FF79DC0B3482FF7A7C96CCFE01D6C', 7, '2014-05-17'),
(14, 'Brodylive', 'jennifer.brody.denis@gmail.com', '*2FB180ACBB7AB0C27D1793C619BA1B118DC77F4A', NULL, '2014-05-19'),
(22, 'Bakanours', 'incruste_2000@hotmail.com', '*922113B95E88C908BA898477AE39BDABEA0F30A9', NULL, '2014-06-06'),
(19, 'tfedwm14', 'tfedwm14@heaj.eu', '*4663838D8C8274837411E03274B2E8EA12CAC237', 11, '2014-05-26'),
(21, 'Jenny42', 'Jenny@gmail.com', '*816D102EA9BB236DA2D0A5C518A088FE6B69315D', 7, '2014-05-26'),
(23, 'test', 'test@test.com', '*1BF3116A5372A85B80F3769F62A5162B482C00EE', NULL, '2014-06-06'),
(24, 'heaj_test', 'jennifer.denis@etud.infographie-sup.eu', '*E56A114692FE0DE073F9A1DD68A00EEB9703F3F1', 5, '2014-06-06'),
(25, 'LuckyLuke', 'denis.dominique@skynet.be', '*42969A63A1451C79992E51DF6AD65227EC06C07B', 1, '2014-06-08');
